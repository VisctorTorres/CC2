[NOMBRE] Victor Torres Varas
[ROL] 201173076-3
[LIBRERIAS] 
#Librerias que se utilizan
import numpy as np
import scipy as sp
import scipy.optimize 

import imutils
import matplotlib.pyplot as plt
from numpy import linalg
from matplotlib.image import imread
from PIL import Image